﻿namespace SManagementWebApp.BLL.Model
{
    public class CompanyModel
    {
        public int Company_Id { get; set; }
        public string Company_Name { get; set; }
    }
}